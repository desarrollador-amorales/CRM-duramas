<?php
$con=mysqli_connect("localhost", "root", "", "crm");
//$con=mysqli_connect("localhost", "bbbn4dd_test", "amorales1923", "bbbn4dd_lead");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

?>
